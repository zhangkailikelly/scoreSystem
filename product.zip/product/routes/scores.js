var express = require('express');
var router = express.Router();

/* GET users listing. */
router.post('/', function(req, res, next) {
	console.log(22222222222);
	global.data=JSON.parse(req.body.data);
	console.log(global.data);
	res.send("success")
});

module.exports = router;
